## Usage

Use the syntax-check command to check syntax in a playbook.

```bash
ansible-playbook *playbookname.yml* --syntax-check
```

Use the ansible-playbook command to execute playbooks after a syntax check.

```bash
ansible-playbook *playbookname.yml*
```
