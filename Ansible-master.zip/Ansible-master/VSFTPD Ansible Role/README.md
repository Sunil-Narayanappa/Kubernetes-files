## Usage

Use the *execute-vsftpd.yml* playbook to execute your vsftpd-ansible Role.
