VSFTPD
=========

A Role to configure a simple VSFTPD server using Ansible.


Important
----------

## The password of user Paul is: 'redhat' without the single quotes.
## This is only tested on CentOS 7.
