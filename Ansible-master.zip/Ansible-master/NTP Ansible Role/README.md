## NTP Ansible role 

  This role will create a simple NTP configuration for server and nodes. Created for educational purposes.
