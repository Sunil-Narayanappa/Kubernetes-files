# kubernetes
## Additional learning material on kubernetes
### You can verify your yaml code online - https://www.yamllint.com/

